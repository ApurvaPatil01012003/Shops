package com.exam.shops;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.datepicker.MaterialDatePicker;

import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class YOYSecondActivity extends AppCompatActivity {
    EditText et_date,edtAchieved,edtQty,edtNob;
    Button btnSave,btnDailyTable;
    private String key;
    private int updatedValue;
private int updatedValueDaily;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_yoysecond);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        et_date = findViewById(R.id.et_date);
        edtAchieved = findViewById(R.id.edtAchieved);
        edtQty = findViewById(R.id.edtQty);
        edtNob = findViewById(R.id.edtNob);
        btnSave = findViewById(R.id.btnSave);
        btnDailyTable=findViewById(R.id.btnDailyTable);

        String Holiday = getIntent().getStringExtra("ShopHoliday");
        if (!Holiday.isEmpty())
        {
            Log.d("Holidqay","Holiday is : "+Holiday);
        }

        int SecondTurnOverValue = getIntent().getIntExtra("TurnYear", 0);
Log.d("TURNOVER","turn over is : ; "+SecondTurnOverValue);

String High_Per_Day=getIntent().getStringExtra("HighPerformance");
int Growth_Per = getIntent().getIntExtra("Growth",0);

//Log.d("HIGHPERFORM","HIGH DAY"+High_Per_Day);
//Log.d("Growth","groth is : "+Growth_Per);

        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Select Date")
                .build();

        et_date.setOnClickListener(v -> {
            if (!datePicker.isAdded()) {
                datePicker.show(getSupportFragmentManager(), "DATE_PICKER");
            }
        });

        datePicker.addOnPositiveButtonClickListener(selection -> {
            et_date.setText(datePicker.getHeaderText());
        });


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = et_date.getText().toString();
                String Achievedstr = edtAchieved.getText().toString();
                String Quantitystr = edtQty.getText().toString();
                String nobstr = edtNob.getText().toString();
                int quantity = 0;
                int Achieved = 0;
                int Nob = 0;
                try {
                    quantity = Integer.parseInt(Quantitystr);
                    Achieved = Integer.parseInt(Achievedstr);
                    Nob = Integer.parseInt(nobstr);

                } catch (Exception e) {
                  //  edtQty.setError("Enter a valid number");
                    return;
                }


                if (!date.isEmpty() && !Achievedstr.isEmpty() && !Quantitystr.isEmpty() && !nobstr.isEmpty()) {
                    SaveDataToSharedPref(date, Integer.parseInt(Achievedstr), Integer.parseInt(Quantitystr), Integer.parseInt(nobstr));
                    Toast.makeText(YOYSecondActivity.this, "Save data", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(YOYSecondActivity.this, "Please fill the all feilds", Toast.LENGTH_SHORT).show();
                }


            }

        });

        btnDailyTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = et_date.getText().toString().trim();
                String Achievedstr = edtAchieved.getText().toString().trim();
                String Quantitystr = edtQty.getText().toString().trim();
                String nobstr = edtNob.getText().toString().trim();

                int achieved = 0, quantity = 0, nob = 0;

                if (!Achievedstr.isEmpty()) {
                    achieved = Integer.parseInt(Achievedstr);
                }

                if (!Quantitystr.isEmpty()) {
                    quantity = Integer.parseInt(Quantitystr);
                }

                if (!nobstr.isEmpty()) {
                    nob = Integer.parseInt(nobstr);
                }

                if (!date.isEmpty()) {
                    SaveDailyDataToSharedPref(date, achieved, quantity, nob);
                }

                Intent intent = new Intent(YOYSecondActivity.this, DailyTableYOY.class);
                intent.putExtra("ShopHoliday", Holiday);
                intent.putExtra("TurnYear", SecondTurnOverValue);
                intent.putExtra("Achived_Value", updatedValueDaily);
                intent.putExtra("Quantity",quantity);
                intent.putExtra("NOB",nob);
                intent.putExtra("HighPerDay",High_Per_Day);
                intent.putExtra("Growth",Growth_Per);

//                Log.d("Updated_Daily", "Updated for daily: " + updatedValueDaily);
//                Log.d("Updated_Daily", "quantity for daily: " + quantity);
//                Log.d("Updated_Daily", "nob for daily: " + nob);
                startActivity(intent);

                ClearAllText();

            }
        });


        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(YOYSecondActivity.this, GoToMAndD.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

                if (key != null && !key.isEmpty()) {
                    intent.putExtra("data_key", key);
                    intent.putExtra("data_value", updatedValue);

                }

                startActivity(intent);
                finish();
            }
        });


    }

    public void ClearAllText() {
        et_date.setText("");
        edtAchieved.setText("");
        edtQty.setText("");
        edtNob.setText("");
    }

    public void SaveDataToSharedPref(String date, int Achieved, int Quantity, int nob) {
        SharedPreferences sharedPreferences = getSharedPreferences("YOY_PREFS", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        String[] parts = date.split(" ");
        String month = parts[1];
        String yearStr = parts[2];
        int year = Integer.parseInt(yearStr);

        String shortMonth = convertToShortMonth(month);

        if (shortMonth.equals("Jan") || shortMonth.equals("Feb") || shortMonth.equals("Mar")) {
            year = Integer.parseInt(yearStr);;
        }

        String key = "data_" + shortMonth + "_" + year + "_Achieved";

        int prev = sharedPreferences.getInt(key, 0);
        int updatedValue = prev + Achieved;

        editor.putInt(key, updatedValue);
        editor.putString("last_selected_date", date);
        editor.apply();

        //Log.d("YOY_DATA", key + " = " + updatedValue);

        this.key = key;
        this.updatedValue = updatedValue;


        //  finish();
    }
    public void SaveDailyDataToSharedPref(String dateInput, int Achieved, int Quantity, int nob) {
        SharedPreferences sharedPreferences = getSharedPreferences("Shop Data", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        SimpleDateFormat inputFormat = new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH);
        SimpleDateFormat saveFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);

        String formattedDate = "";
        try {
            formattedDate = saveFormat.format(inputFormat.parse(dateInput));
        } catch (Exception e) {
            e.printStackTrace();
        }

        String key = "Achieved_" + formattedDate;
        String keyQty = "Quantity_" + formattedDate;
        String keyNob = "NOB_" + formattedDate;


        int prev = sharedPreferences.getInt(key, 0);
        int prevQty = sharedPreferences.getInt(keyQty, 0);
        int prevNob = sharedPreferences.getInt(keyNob, 0);

        updatedValueDaily = prev + Achieved;
        int updatedQty = prevQty + Quantity;
        int updatedNob = prevNob + nob;

        editor.putInt(key, updatedValueDaily);
        editor.putInt(keyQty, updatedQty);
        editor.putInt(keyNob, updatedNob);

        editor.putString("last_selected_date", formattedDate);
        editor.apply();

        Log.d("YOY_DATA_ForDaily", key + " = " + updatedValueDaily);
        Log.d("YOY_DATA_ForDaily", keyQty + " = " + Quantity);
        Log.d("YOY_DATA_ForDaily", keyNob + " = " + nob);

        this.key = key;
        this.updatedValueDaily = updatedValueDaily;

    }


    private String convertToShortMonth(String fullMonth) {
        switch (fullMonth) {
            case "January":
                return "Jan";
            case "February":
                return "Feb";
            case "March":
                return "Mar";
            case "April":
                return "Apr";
            case "May":
                return "May";
            case "June":
                return "Jun";
            case "July":
                return "Jul";
            case "August":
                return "Aug";
            case "September":
                return "Sep";
            case "October":
                return "Oct";
            case "November":
                return "Nov";
            case "December":
                return "Dec";
            default:
                return fullMonth;
        }


    }


}

