package com.exam.shops;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.List;

public class YOYActivity extends AppCompatActivity {
    TextView txtTurnOver;
    TableLayout tableLayout;
    int Turnover;

    Context context ;

    List<String> months = Arrays.asList(
            "April", "May", "June", "July", "August", "September",
            "October", "November", "December", "January", "February", "March");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_yoyactivity);
        context=getApplicationContext();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tableLayout = findViewById(R.id.tableLayout);
        txtTurnOver = findViewById(R.id.txtTurnOver);
        Turnover = getIntent().getIntExtra("TurnYear",0);
        txtTurnOver.setText(String.valueOf(Turnover));




        Log.d("Turnover", "turn over before : " + Turnover);

        String TURNOVER = txtTurnOver.getText().toString();
        String VALUE =txtTurnOver.getText().toString();
        SharedPreferences sharedPref = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("TurnOver", TURNOVER);

        editor.apply();

        Log.d("TURNOVER", "TURN oVER Is : " + TURNOVER);


        addHeaderRow();
        addMonthRows();

    }


    private void addHeaderRow() {
        TableRow header = new TableRow(this);
        header.setBackgroundColor(Color.parseColor("#E0E0E0"));


        String[] headers = {"Month", "2025-26(Exp)", "2025-26(Ach)", "Achieved %"};
        for (String title : headers) {
            TextView tv = new TextView(this);
            tv.setText(title);

            tv.setPadding(20, 20, 20, 20);
            tv.setTextSize(16);
            tv.setTypeface(Typeface.DEFAULT_BOLD);
            tv.setTextColor(Color.BLACK);
            tv.setGravity(Gravity.CENTER);
            header.addView(tv);
        }

        tableLayout.addView(header);

    }

    private void addMonthRows() {
        boolean alternate = false;
        SharedPreferences prefs = getSharedPreferences("YOY_PREFS", MODE_PRIVATE);

        for (String month : months) {
            TableRow row = new TableRow(this);
            row.setBackgroundColor(alternate ? Color.parseColor("#F7F7F7") : Color.WHITE);
            alternate = !alternate;

            // Month TextView
            TextView tvMonth = new TextView(this);
            tvMonth.setText(month);
            tvMonth.setPadding(16, 16, 16, 16);
            tvMonth.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(tvMonth);


            //EditText et2025_26 = createEditText();
           // EditText etAchieved = createEditText();

            TextView et2025_26=new TextView(this);
            String shortMonth = convertToShortMonth(month);
            float monthlyExpected = Turnover / 12.0f;
            et2025_26.setText(String.format("%.2f", monthlyExpected));
            et2025_26.setPadding(16, 16, 16, 16);
            et2025_26.setGravity(Gravity.CENTER);
            et2025_26.setTextColor(Color.BLACK);

            GestureDetector gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    showEditTurnOverDialog(et2025_26, shortMonth);
                    return super.onDoubleTap(e);
                }
            });
            et2025_26.setOnTouchListener((v, event) -> {
                gestureDetector.onTouchEvent(event);
                return true;
            });


            TextView etAchieved=new TextView(this);
            String Achieved = getAsString(prefs, "data_" + shortMonth + "_2025_26_Achieved");
            if (Achieved.equals("null")) Achieved = "0";
            etAchieved.setText(Achieved);
            etAchieved.setPadding(16, 16, 16, 16);
            etAchieved.setGravity(Gravity.CENTER);
            etAchieved.setTextColor(Color.BLACK);

            GestureDetector gestureAchieved = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    showEditDialog(etAchieved, shortMonth + "_2025_26_Achieved");
                    return super.onDoubleTap(e);
                }
            });

            etAchieved.setOnTouchListener((v, event) -> {
                gestureAchieved.onTouchEvent(event);
                return true;
            });

            row.addView(et2025_26);
            row.addView(etAchieved);


            TextView tvAchievedPer = new TextView(this);
            tvAchievedPer.setText("--");
            tvAchievedPer.setGravity(Gravity.CENTER);
            tvAchievedPer.setPadding(16, 16, 16, 16);
            row.addView(tvAchievedPer);


            new Handler(Looper.getMainLooper()).post(() -> {
                String expectedStr = et2025_26.getText().toString().trim();
                String achievedStr = etAchieved.getText().toString().trim();

                float expected = 0, achievedVal = 0;
                try {
                    expected = Float.parseFloat(expectedStr);
                } catch (Exception ignored) {}

                try {
                    achievedVal = Float.parseFloat(achievedStr);
                } catch (Exception ignored) {}

                String percentageText = "--";
                int colorResId = R.color.medium_percentage;
                if (expected != 0) {
                    float percent = ((achievedVal) / expected) * 100;
                    if (percent >= 0 && percent < 70) {
                        colorResId = R.color.high_percentage;
                    } else if (percent >= 70 && percent < 90) {
                        colorResId = R.color.medium_percentage;

                    }else {
                        colorResId = R.color.low_percentage;

                    }

                    percentageText = String.format("%.2f%%", percent);
                }

                tvAchievedPer.setText(percentageText);
                tvAchievedPer.setTextColor(ContextCompat.getColor(getApplicationContext(), colorResId));



                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("data_" + shortMonth + "_2025_26", expectedStr);
                editor.putString("data_" + shortMonth + "_2025_26_Achieved", achievedStr);
                editor.putString("data_" + shortMonth + "_2025_26_AchievedPecentage", percentageText);
                editor.apply();
            });


            TextWatcher watcher = new TextWatcher() {
                @Override
                public void afterTextChanged(Editable s) {
                    String expectedStr = et2025_26.getText().toString().trim();
                    String achievedStr = etAchieved.getText().toString().trim();

                    float expected = 0, achieved = 0;
                    try {
                        expected = Float.parseFloat(expectedStr);
                    } catch (Exception ignored) {}

                    try {
                        achieved = Float.parseFloat(achievedStr);
                    } catch (Exception ignored) {}

                    String percentageText = "--";
                    if (expected != 0) {
                        float percent = (achieved / expected) * 100;
                        percentageText = String.format("%.2f%%", percent);

                        Log.d("WATCHER", "Expected: " + expectedStr + ", Achieved: " + achievedStr);
                        tvAchievedPer.setText(percentageText);


                        if (percent >= 0 && percent < 70) {
                            tvAchievedPer.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.low_percentage));
                        } else if (percent >= 70 && percent < 90) {
                            tvAchievedPer.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.medium_percentage));
                        } else {
                            tvAchievedPer.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.high_percentage));
                        }

                    }
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("data_" + shortMonth + "_2025_26", expectedStr);
                    editor.putString("data_" + shortMonth + "_2025_26_Achieved", achievedStr);
                    editor.putString("data_" + shortMonth + "_2025_26_AchievedPecentage", percentageText);
                    editor.apply();
                }

                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                public void onTextChanged(CharSequence s, int start, int before, int count) {}
            };
            et2025_26.addTextChangedListener(watcher);
            etAchieved.addTextChangedListener(watcher);

            tableLayout.addView(row);
        }
    }


    private String getAsString(SharedPreferences prefs, String key) {
        Object value = prefs.getAll().get(key);
        if (value == null) return "0";
        return String.valueOf(value);
    }


    private String convertToShortMonth(String fullMonth) {
        switch (fullMonth) {
            case "January": return "Jan";
            case "February": return "Feb";
            case "March": return "Mar";
            case "April": return "Apr";
            case "May": return "May";
            case "June": return "Jun";
            case "July": return "Jul";
            case "August": return "Aug";
            case "September": return "Sep";
            case "October": return "Oct";
            case "November": return "Nov";
            case "December": return "Dec";
            default: return fullMonth;
        }
        }


    private EditText createEditText() {
        EditText editText = new EditText(this);
        editText.setHint("0");
        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        editText.setPadding(16, 16, 16, 16);
        editText.setBackgroundResource(R.drawable.bg_edittext_rounded);
        editText.setGravity(Gravity.CENTER);
        editText.setFocusable(true);
        editText.setFocusableInTouchMode(true);
        editText.setClickable(true);
        return editText;



    }

    private void showEditDialog(TextView targetView, String prefKey) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Value");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(targetView.getText().toString());

        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newValue = input.getText().toString().trim();
            targetView.setText(newValue);
            updatePercentage(targetView);


            SharedPreferences prefs = getSharedPreferences("YOY_PREFS", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("data_" + prefKey, newValue);
            editor.apply();

        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
    private void showEditTurnOverDialog(TextView targetView, String shortMonth) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Expected Turnover");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(targetView.getText().toString());

        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newValue = input.getText().toString().trim();
            targetView.setText(newValue);
            updatePercentage(targetView);


            // Save to SharedPreferences
            SharedPreferences prefs = getSharedPreferences("YOY_PREFS", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("data_" + shortMonth + "_2025_26", newValue);
            editor.apply();


        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }


    private void updatePercentage(TextView updatedView) {
        TableRow row = (TableRow) updatedView.getParent();
        TextView expectedView = (TextView) row.getChildAt(1);
        TextView achievedView = (TextView) row.getChildAt(2);
        TextView percentageView = (TextView) row.getChildAt(3);

        float expected = 0, achieved = 0;
        try {
            expected = Float.parseFloat(expectedView.getText().toString());
            achieved = Float.parseFloat(achievedView.getText().toString());
        } catch (Exception ignored) {}

        String percentText = "--";
        int colorResId = R.color.medium_percentage;
        if (expected != 0) {
            float percent = (achieved / expected) * 100;


            if (percent >= 0 && percent < 70) {
                colorResId = R.color.high_percentage;
            } else if (percent >= 70 && percent < 90) {
                colorResId = R.color.medium_percentage;

            }else {
                colorResId = R.color.low_percentage;

            }

            percentText = String.format("%.2f%%", percent);


        }

        percentageView.setText(percentText);
        percentageView.setTextColor(ContextCompat.getColor(updatedView.getContext(), colorResId));


        String shortMonth = convertToShortMonth(((TextView) row.getChildAt(0)).getText().toString());
        SharedPreferences.Editor editor = getSharedPreferences("YOY_PREFS", MODE_PRIVATE).edit();
        editor.putString("data_" + shortMonth + "_2025_26", String.valueOf(expected));
        editor.putString("data_" + shortMonth + "_2025_26_Achieved", String.valueOf(achieved));
        editor.putString("data_" + shortMonth + "_2025_26_AchievedPecentage", percentText);
        editor.apply();
    }




}
