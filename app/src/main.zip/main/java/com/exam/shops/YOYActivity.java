package com.exam.shops;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class YOYActivity extends AppCompatActivity {

    TextView txtTurnOver;
    TableLayout tableLayout;
   // int Turnover;
    int Result;
    String financialYear;

    List<String> months = Arrays.asList(
            "April", "May", "June", "July", "August", "September",
            "October", "November", "December", "January", "February", "March"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoyactivity);

        txtTurnOver = findViewById(R.id.txtTurnOver);
        tableLayout = findViewById(R.id.tableLayout);
        Result = getIntent().getIntExtra("ResultTurnover", 0);
        txtTurnOver.setText("Yearly Target : " + String.valueOf(Result));

       // Turnover = getIntent().getIntExtra("TurnYear", 0);
        financialYear = getCurrentFinancialYear();

       // txtTurnOver.setText("Yearly Target : "+String.valueOf(Turnover));



        SharedPreferences sharedPref = getSharedPreferences("MyPrefs", MODE_PRIVATE);
       // sharedPref.edit().putString("TurnOver", String.valueOf(Turnover)).apply();
        sharedPref.edit().putString("ResultTurnOver", String.valueOf(Result)).apply();


        //addHeaderRow();
        addMonthRows();
    }


    private void addMonthRows() {
        SharedPreferences prefs = getSharedPreferences("YOY_PREFS", MODE_PRIVATE);
        String[] parts = financialYear.split("_");
        int fyStartYear = Integer.parseInt(parts[0]);

        for (String month : months) {
            String shortMonth = convertToShortMonth(month);
            int dataYear = (shortMonth.equals("Jan") || shortMonth.equals("Feb") || shortMonth.equals("Mar")) ? fyStartYear + 1 : fyStartYear;

            float expected = prefs.getFloat("expected_" + shortMonth + "_" + dataYear, Result / 12.0f);
            int achieved = prefs.getInt("data_" + shortMonth + "_" + dataYear + "_Achieved", 0);
            float percent = (expected != 0) ? (achieved / expected) * 100 : 0;

            // CardView
            CardView cardView = new CardView(this);
            CardView.LayoutParams cardParams = new CardView.LayoutParams(
                    CardView.LayoutParams.MATCH_PARENT,
                    CardView.LayoutParams.WRAP_CONTENT
            );
            cardParams.setMargins(0, 0, 0, 32);
            cardView.setLayoutParams(cardParams);
            cardView.setCardElevation(8f);
            cardView.setRadius(24f);
            cardView.setUseCompatPadding(true);
            cardView.setPreventCornerOverlap(true);
            cardView.setCardBackgroundColor(Color.WHITE);

            // Inner layout
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(32, 32, 32, 32);

            // Month
            TextView tvMonth = createText("Month: " + month, 16, Typeface.BOLD);
            layout.addView(tvMonth);

            // Target row
            LinearLayout targetRow = createLabeledRow("Target: ₹" + String.format("%.0f", expected));
            TextView tvTarget = (TextView) targetRow.getChildAt(0);
            ImageView ivEditTarget = (ImageView) targetRow.getChildAt(1);
            ivEditTarget.setOnClickListener(v -> showEditDialog(tvTarget, shortMonth, true));
            layout.addView(targetRow);

            // Achieved row
            LinearLayout achievedRow = createLabeledRow("Achieved: ₹" + achieved);
            TextView tvAchieved = (TextView) achievedRow.getChildAt(0);
            ImageView ivEditAchieved = (ImageView) achievedRow.getChildAt(1);
            ivEditAchieved.setOnClickListener(v -> showEditDialog(tvAchieved, shortMonth, false));
            layout.addView(achievedRow);

            // Percentage
            TextView tvPercentage = createText("Achieved Percentage: " + String.format("%.0f", percent) + "%", 14, Typeface.NORMAL);
            layout.addView(tvPercentage);

            updatePercentage(tvTarget, tvAchieved, tvPercentage, shortMonth, prefs);


            cardView.addView(layout);
            tableLayout.addView(cardView);

            ivEditTarget.setOnClickListener(v -> {
                showSingleEditDialog(tvTarget, tvAchieved, tvPercentage, shortMonth, true);
            });

            ivEditAchieved.setOnClickListener(v -> {
                showSingleEditDialog(tvTarget, tvAchieved, tvPercentage, shortMonth, false);
            });


        }
    }




    private void showEditDialog(TextView targetView, String shortMonth, boolean isExpected) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isExpected ? "Edit Expected Turnover" : "Edit Achieved Value");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(targetView.getText().toString());
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newValue = input.getText().toString().trim();
            targetView.setText(newValue);

            TableRow row = (TableRow) targetView.getParent();
            TextView tvExpected = (TextView) row.getChildAt(1);
            TextView tvAchieved = (TextView) row.getChildAt(2);
            TextView tvPercentage = (TextView) row.getChildAt(3);

            updatePercentage(tvExpected, tvAchieved, tvPercentage, shortMonth,
                    getSharedPreferences("YOY_PREFS", MODE_PRIVATE));


            SharedPreferences prefs = getSharedPreferences("YOY_PREFS", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            // Get financial year start from the `financialYear` string
            String[] parts = financialYear.split("_");
            int fyStartYear = Integer.parseInt(parts[0]);
            int dataYear = (shortMonth.equals("Jan") || shortMonth.equals("Feb") || shortMonth.equals("Mar"))
                    ? fyStartYear + 1 : fyStartYear;

            if (isExpected) {
                editor.putFloat("expected_" + shortMonth + "_" + dataYear, Float.parseFloat(newValue));
            } else {
                editor.putInt("data_" + shortMonth + "_" + dataYear + "_Achieved", Integer.parseInt(newValue));
            }

            editor.apply();

        });


        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }


    private void showSingleEditDialog(TextView tvTarget, TextView tvAchieved, TextView tvPercentage,
                                      String shortMonth, boolean isTargetEdit) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isTargetEdit ? "Edit Target" : "Edit Achieved");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        String current = isTargetEdit ? tvTarget.getText().toString() : tvAchieved.getText().toString();
        input.setText(parseNumericOnly(current));

        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newValue = input.getText().toString().trim();
            if (isTargetEdit) {
                tvTarget.setText("Target: ₹" + newValue);
            } else {
                tvAchieved.setText("Achieved: ₹" + newValue);
            }

            SharedPreferences prefs = getSharedPreferences("YOY_PREFS", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            String[] parts = financialYear.split("_");
            int fyStartYear = Integer.parseInt(parts[0]);
            int dataYear = (shortMonth.equals("Jan") || shortMonth.equals("Feb") || shortMonth.equals("Mar"))
                    ? fyStartYear + 1 : fyStartYear;

            if (isTargetEdit) {
                editor.putFloat("expected_" + shortMonth + "_" + dataYear, parseFloat(newValue));
            } else {
                editor.putInt("data_" + shortMonth + "_" + dataYear + "_Achieved", (int) parseFloat(newValue));
            }

            editor.apply();

            // Update percentage
            updatePercentage(tvTarget, tvAchieved, tvPercentage, shortMonth, prefs);
            addTextWatcher(tvTarget, tvAchieved, tvPercentage, shortMonth);
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }


    private void updatePercentage(TextView expectedView, TextView achievedView, TextView percentView,
                                  String shortMonth, SharedPreferences prefs) {
        new Handler(Looper.getMainLooper()).post(() -> {
            float expected = parseFloat(expectedView.getText().toString());
            float achieved = parseFloat(achievedView.getText().toString());
            String percentText = "--";
            int colorResId = R.color.Black;

            if (expected != 0) {
                float percent = (achieved / expected) * 100;
                percentText = String.format("%.2f%%", percent);

                if (percent>=0 && percent < 70) {
                    colorResId = R.color.Green;
                } else if (percent >=70 && percent < 90) {
                    colorResId = R.color.Black;
                } else {
                    colorResId = R.color.Red;
                }
            }

            percentView.setText(percentText);
            percentView.setTextColor(ContextCompat.getColor(this, colorResId));

            prefs.edit()
                    .putString("data_" + shortMonth + "_" + financialYear, expectedView.getText().toString())
                    .putString("data_" + shortMonth + "_" + financialYear + "_Achieved", achievedView.getText().toString())
                    .putString("data_" + shortMonth + "_" + financialYear + "_AchievedPecentage", percentText)
                    .apply();
        });
    }

    private void addTextWatcher(TextView expectedView, TextView achievedView, TextView percentView, String shortMonth) {
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                float expected = parseFloat(expectedView.getText().toString());
                float achieved = parseFloat(achievedView.getText().toString());

                String percentText = "--";
                int colorResId = R.color.Black;

                if (expected != 0) {
                    float percent = (achieved / expected) * 100;
                    percentText = String.format("%.2f%%", percent);
                    if (percent>=0 && percent < 70) {
                        colorResId = R.color.Green;
                    } else if (percent >=70 && percent < 90) {
                        colorResId = R.color.Black;
                    } else {
                        colorResId = R.color.Red;
                    }
                }

                percentView.setText(percentText);
                percentView.setTextColor(ContextCompat.getColor(getApplicationContext(), colorResId));

                SharedPreferences.Editor editor = getSharedPreferences("YOY_PREFS", MODE_PRIVATE).edit();
                editor.putString("data_" + shortMonth + "_" + financialYear, expectedView.getText().toString());
                editor.putString("data_" + shortMonth + "_" + financialYear + "_Achieved", achievedView.getText().toString());
                editor.putString("data_" + shortMonth + "_" + financialYear + "_AchievedPecentage", percentText);
                editor.apply();
            }
        };

        expectedView.addTextChangedListener(watcher);
        achievedView.addTextChangedListener(watcher);
    }

    private float parseFloat(String value) {
        try {
            return Float.parseFloat(value.replaceAll("[^\\d.]", "").trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private String parseNumericOnly(String value) {
        return value.replaceAll("[^\\d.]", "");
    }


    private String convertToShortMonth(String fullMonth) {
        switch (fullMonth) {
            case "January": return "Jan";
            case "February": return "Feb";
            case "March": return "Mar";
            case "April": return "Apr";
            case "May": return "May";
            case "June": return "Jun";
            case "July": return "Jul";
            case "August": return "Aug";
            case "September": return "Sep";
            case "October": return "Oct";
            case "November": return "Nov";
            case "December": return "Dec";
            default: return fullMonth;
        }
    }

    private String getCurrentFinancialYear() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        int startYear, endYear;
        if (month >= Calendar.APRIL) {
            startYear = year;
            endYear = year + 1;
        } else {
            startYear = year - 1;
            endYear = year;
        }
        return startYear + "_" + String.valueOf(endYear).substring(2);
    }

    private TextView createText(String text, int sizeSp, int style) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, style);
        tv.setTextColor(Color.parseColor("#333333"));
        tv.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        return tv;
    }

    private LinearLayout createLabeledRow(String text) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        row.setPadding(0, 16, 0, 0);

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setTextColor(Color.parseColor("#333333"));
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.ic_edit);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(60, 60);
        iv.setLayoutParams(iconParams);
        iv.setPadding(8, 8, 8, 8);

        row.addView(tv);
        row.addView(iv);

        return row;
    }



}
