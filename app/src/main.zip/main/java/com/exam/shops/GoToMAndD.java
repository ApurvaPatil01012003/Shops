package com.exam.shops;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class GoToMAndD extends AppCompatActivity {
    Button btnyes, btnDyes;

    CardView cardviewDaily;
    TextView txtDate, txtDay, txtExpect, txtAchived, txtAchievedPer, txtType, txtShopName;
    BarChart barChart;
    PieChart pieChart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_go_to_mand_d);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnyes = findViewById(R.id.btnyes);
        btnDyes = findViewById(R.id.btnDyes);
        cardviewDaily = findViewById(R.id.cardviewDaily);
        txtDate = findViewById(R.id.txtDate);
        txtDay = findViewById(R.id.txtDay);
        txtType = findViewById(R.id.txtType);
        txtExpect = findViewById(R.id.txtExpect);
        txtAchived = findViewById(R.id.txtAchived);
        txtAchievedPer = findViewById(R.id.txtAchievedPer);
        barChart = findViewById(R.id.barChart);
        pieChart = findViewById(R.id.pieChart);
        txtShopName = findViewById(R.id.txtShopName);
        String shopname = getIntent().getStringExtra("ShopName");

        Log.d("GOTOACTIVITY", "ShopName is : " + shopname);


        setUpBarchart();
        setupPieChart();


        Intent intent = getIntent();
int Result =intent.getIntExtra("ResultTurnover",-1);
        int SecondTurnOverValue = intent.getIntExtra("TurnOver", -1);
        String Holiday = intent.getStringExtra("shopsHoliday");
        String HighPerDay = intent.getStringExtra("HighPerformace");
        int growth = intent.getIntExtra("EdtGrowth", -1);


        SharedPreferences prefs = getSharedPreferences("ShopData", MODE_PRIVATE);
        if (Result == -1) {
            Result = prefs.getInt("Result_TURNOVER", 0);
        }
        if (SecondTurnOverValue == -1) {
            SecondTurnOverValue = prefs.getInt("TURNOVER", 0);
        }
        if (Holiday == null || Holiday.equals("Select Day")) {
            Holiday = prefs.getString("Shop_Holiday", "");
        }
        if (HighPerDay == null || HighPerDay.isEmpty()) {
            HighPerDay = prefs.getString("selected_days", "");
        }
        if (growth == -1) {
            growth = prefs.getInt("Growth", 0);
        }

        if (shopname == null || shopname.isEmpty()) {
            shopname = prefs.getString("ShopName", "");
        }

        txtShopName.setText(shopname);
        Log.d("GOTOACTIVITY", "ShopName is : " + shopname);

        Log.d("GoToMAndD", "From SharedPref or Intent:");
        Log.d("GoToMAndD", "TurnOver: " + SecondTurnOverValue);
        Log.d("GoToMAndD", "TurnOver Result: " + Result);

        Log.d("GoToMAndD", "Holiday: " + Holiday);
        Log.d("GoToMAndD", "HighPerDay: " + HighPerDay);
        Log.d("GoToMAndD", "Growth: " + growth);


        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("Result_TURNOVER",Result);
        editor.putInt("TURNOVER", SecondTurnOverValue);
        editor.putString("Shop_Holiday", Holiday);
        editor.putString("selected_days", HighPerDay);
        editor.putInt("Growth", growth);
        editor.putString("ShopName", shopname);
        editor.apply();


        int finalSecondTurnOverValue = SecondTurnOverValue;
        int finalResult = Result;
        btnyes.setOnClickListener(v -> {
            Intent i = new Intent(GoToMAndD.this, YOYActivity.class);
            i.putExtra("TurnYear", finalSecondTurnOverValue);
            i.putExtra("ResultTurnYear",finalResult);
            startActivity(i);
        });

        String finalHoliday = Holiday;
        int finalSecondTurnOverValue1 = SecondTurnOverValue;
        int finalResult1 = Result;
        String finalHighPerDay = HighPerDay;
        int finalGrowth = growth;
        btnDyes.setOnClickListener(v -> {
            Intent i = new Intent(GoToMAndD.this, YOYSecondActivity.class);
            i.putExtra("ShopHoliday", finalHoliday);
            i.putExtra("TurnYear", finalSecondTurnOverValue1);
            i.putExtra("ResultTurnYear", finalResult1);
            i.putExtra("HighPerformance", finalHighPerDay);
            i.putExtra("Growth", finalGrowth);
            startActivity(i);
        });


        LocalDate currentDate = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            currentDate = LocalDate.now();
        }
        String date = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            date = currentDate.getMonth().name().substring(0, 1).toUpperCase() +
                    currentDate.getMonth().name().substring(1).toLowerCase() + " " +
                    currentDate.getDayOfMonth() + ", " + currentDate.getYear();
        }
        String day = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            day = currentDate.getDayOfWeek().name().substring(0, 1).toUpperCase() +
                    currentDate.getDayOfWeek().name().substring(1).toLowerCase();
        }

        txtDate.setText(date);
        txtDay.setText(day);

        TodayDataUtils.updateTodayData(GoToMAndD.this);
        updateTodaysCard();
    }

    private void setUpBarchart() {
        float[][] salesData = {
                {120000, 50000},
                {130000, 70000},
                {110000, 60000},
                {115000, 65000},
                {125000, 55000},
                {140000, 80000},
                {118000, 60000},

        };

        String[] months = {"April", "August", "December", "February", "January", "July", "June", "March", "May", "November", "October", "September"};

        ArrayList<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < salesData.length; i++) {
            entries.add(new BarEntry(i, salesData[i]));
        }

        // Creating dataset for stacked bars
        BarDataSet barDataSet = new BarDataSet(entries, "Sales Data");
        barDataSet.setColors(new int[]{Color.BLUE, Color.parseColor("#FFA500")});
        barDataSet.setStackLabels(new String[]{"Monthly Target", "Actual Sales"});
        barDataSet.setDrawValues(true);
        barDataSet.setValueTextSize(12f);
        barDataSet.setValueTextColor(Color.WHITE);

        // Custom Value Formatter to Display Values Inside Bars
        barDataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getBarStackedLabel(float value, BarEntry entry) {
                return String.valueOf((int) value);
            }
        });


        BarData barData = new BarData(barDataSet);
        barChart.setData(barData);
        Description description = new Description();
        description.setText("Monthly Target vs Actual Sales");
        description.setTextSize(14f);
        description.setTextColor(Color.BLACK);
        description.setPosition(barChart.getWidth() / 2f, 50f);
        barChart.setDescription(description);

        barChart.animateY(1000);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(months));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setLabelRotationAngle(0);
        xAxis.setDrawGridLines(false);


        YAxis leftAxis = barChart.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setGranularity(20000f);
        leftAxis.setDrawGridLines(true);
        barChart.getAxisRight().setEnabled(false); // Disable right Y-axis

        // Customize Legend
        Legend legend = barChart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        legend.setOrientation(Legend.LegendOrientation.VERTICAL);
        legend.setDrawInside(true);

        barChart.invalidate();

    }


    private void setupPieChart() {
        String[] months = {"October", "February", "January", "July", "September",
                "December", "November", "May", "August", "April", "March", "June"};
        float[] actualSalesPercentage = {7.0f, 9.3f, 8.6f, 9.3f, 8.9f,
                9.0f, 6.9f, 8.5f, 9.8f, 7.8f, 7.4f, 7.4f};


        ArrayList<PieEntry> entries = new ArrayList<>();
        for (int i = 0; i < months.length; i++) {
            entries.add(new PieEntry(actualSalesPercentage[i], months[i]));
        }

        // Set PieDataSet
        PieDataSet dataSet = new PieDataSet(entries, "Monthly Sales Distribution");
        dataSet.setColors(new int[]{
                Color.parseColor("#FFD700"),
                Color.parseColor("#228B22"),
                Color.parseColor("#FF69B4"),
                Color.parseColor("#DC143C"),
                Color.parseColor("#8B4513"),
                Color.parseColor("#32CD32"),
                Color.parseColor("#4B0082"),
                Color.parseColor("#FFA500"),
                Color.parseColor("#4682B4"),
                Color.parseColor("#ADD8E6"),
                Color.parseColor("#FF4500"),
                Color.parseColor("#F4A460")
        });

        // Ensure labels are outside
        dataSet.setXValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
        dataSet.setValueLinePart1OffsetPercentage(100.f);
        dataSet.setValueLinePart1Length(0.6f);
        dataSet.setValueLinePart2Length(0.4f);
        dataSet.setValueLineColor(Color.BLACK);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.BLACK);

        // Set Pie Data
        PieData data = new PieData(dataSet);
        pieChart.setData(data);

        // Customize Pie Chart
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawEntryLabels(false);
        pieChart.setHoleRadius(0f);
        pieChart.setTransparentCircleRadius(0f);
        pieChart.animateY(1000);

        // Customize Legend
        Legend legend = pieChart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        legend.setOrientation(Legend.LegendOrientation.VERTICAL);
        legend.setDrawInside(false);

        // Refresh Chart
        pieChart.invalidate();
    }


    @Override
    protected void onResume() {
        super.onResume();
        TodayDataUtils.updateTodayData(GoToMAndD.this);
        updateTodaysCard();

    }


    public void updateTodaysCard() {
        SharedPreferences todayPrefs = getSharedPreferences("TodayData", MODE_PRIVATE);
        int todayAchieved = todayPrefs.getInt("today_achieved", 0);
        String todayExpected = todayPrefs.getString("today_expected", "0.00");
        float todayPercent = todayPrefs.getFloat("today_percent", 0f);
        String todayType = todayPrefs.getString("today_type", "N/A");


        txtExpect.setText("Expected : ₹" + todayExpected);
        txtAchived.setText("Achieved : ₹" + todayAchieved);
        txtAchievedPer.setText("Achieved % : " + String.format(Locale.US, "%.2f", todayPercent) + "%");
        txtType.setText("Type : " + todayType);

        Log.d("GOToMandD","Expected"+todayExpected);
        Log.d("GOToMandD","Achieved"+todayAchieved);

    }


}